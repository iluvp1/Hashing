#include <string>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "ItemPallet.hpp"

using std::string;
using std::ifstream;
using std::cout;
using std::endl;

// function to return the hash value based on the first digit
unsigned int hashfct1(unsigned int sku)
{
  return sku / 100000 % 10;
}

// function to return the hash value based on the second digit
unsigned int hashfct2(unsigned int sku)
{
  return sku / 10000 % 10;
}

// function to return the hash value based on the third digit
unsigned int hashfct3(unsigned int sku)
{
  return sku / 1000 % 10;
}

// function to return the hash value based on the fourth digit
unsigned int hashfct4(unsigned int sku)
{
  return sku / 100 % 10;
}

// function to return the hash value based on the fifth digit
unsigned int hashfct5(unsigned int sku)
{
  return sku / 10 % 10;
}

// function to return the hash value based on the fourth digit
unsigned int hashfct6(unsigned int sku)
{
  return sku / 1 % 10;
}

// Constructor for struct Item
Item::Item(string itemName, unsigned int sku) : itemName_(itemName), sku_(sku){};

// Load information from a text file with the given filename
// THIS FUNCTION IS COMPLETE
void ItemPallet::readTextfile(string filename)
{
  ifstream myfile(filename);

  if (myfile.is_open())
  {
    cout << "Successfully opened file " << filename << endl;
    string itemName;
    unsigned int sku;
    while (myfile >> itemName >> sku)
    {
      if (itemName.size() > 0)
        addItem(itemName, sku);
    }
    myfile.close();
  }
  else
    throw std::invalid_argument("Could not open file " + filename);
}

void ItemPallet::addItem(string itemName, unsigned int sku)
{
  Item NewItem(itemName, sku); //stores itemName and sku into NewItem
	
  hT1.emplace(sku, NewItem); //adds onto hash tables
  hT2.emplace(sku, NewItem);
  hT3.emplace(sku, NewItem);
  hT4.emplace(sku, NewItem);
  hT5.emplace(sku, NewItem);
  hT6.emplace(sku, NewItem);
}

bool ItemPallet::removeItem(unsigned int sku) {
//finds sku and if found then erases for all the hashes, returns true
  if (hT1.find(sku) != hT1.end())
  {
    hT1.erase(sku);
    hT2.erase(sku);
    hT3.erase(sku);
    hT4.erase(sku);
    hT5.erase(sku);
    hT6.erase(sku);
    return true;
  }
  else
  {
    return false; // returns false
  }
}

unsigned int ItemPallet::bestHashing() {

  std::pair<unsigned int, unsigned int> current_lowest; //declaration
  
  //set intital max and min bucket size for each hash table (first bucket's size)
  unsigned max1 = hT1.bucket_size(0);
  unsigned min1 = hT1.bucket_size(0);

  unsigned max2 = hT2.bucket_size(0);
  unsigned min2 = hT2.bucket_size(0);

  unsigned max3 = hT3.bucket_size(0);
  unsigned min3 = hT3.bucket_size(0);

  unsigned max4 = hT4.bucket_size(0);
  unsigned min4 = hT4.bucket_size(0);

  unsigned max5 = hT5.bucket_size(0);
  unsigned min5 = hT5.bucket_size(0);

  unsigned max6 = hT6.bucket_size(0);
  unsigned min6 = hT6.bucket_size(0);

  for (unsigned i = 0; i < 10; ++i)// for each bucket in the hash tables
  {
	//======= table 1 ===========================================================================================================

    if (hT1.bucket_size(i) > max1) //if bucket size is bigger than the current max then set that as the new max
    {
      max1 = hT1.bucket_size(i);
    }
    if (hT1.bucket_size(i) < min1) //if bucket size is smaller than the current min then set that as the new min
    {
      min1 = hT1.bucket_size(i);
    }

	//======= table 2 ===========================================================================================================

    if (hT2.bucket_size(i) > max2) //if bucket size is bigger than the current max then set that as the new max
    {
      max2 = hT2.bucket_size(i);
    }
    if (hT2.bucket_size(i) < min2) //if bucket size is smaller than the current min then set that as the new min
    {
      min2 = hT2.bucket_size(i);
    }

	//======= table 3 ===========================================================================================================

    if (hT3.bucket_size(i) > max3) //if bucket size is bigger than the current max then set that as the new max
    {
      max3 = hT3.bucket_size(i);
    }
    if (hT3.bucket_size(i) < min3) //if bucket size is smaller than the current min then set that as the new min
    {
      min3 = hT3.bucket_size(i);
    }

	//======= table 4 ===========================================================================================================

    if (hT4.bucket_size(i) > max4) //if bucket size is bigger than the current max then set that as the new max
    {
      max4 = hT4.bucket_size(i);
    }
    if (hT4.bucket_size(i) < min4) //if bucket size is smaller than the current min then set that as the new min
    {
      min4 = hT4.bucket_size(i);
    }

	//======= table 5 ===========================================================================================================

    if (hT5.bucket_size(i) > max5) //if bucket size is bigger than the current max then set that as the new max
    {
      max5 = hT5.bucket_size(i);
    }
    if (hT5.bucket_size(i) < min5) //if bucket size is smaller than the current min then set that as the new min
    {
      min5 = hT5.bucket_size(i);
    }

	//======= table 6 ===========================================================================================================

    if (hT6.bucket_size(i) > max6) //if bucket size is bigger than the current max then set that as the new max
    {
      max6 = hT6.bucket_size(i);
    }
    if (hT6.bucket_size(i) < min6) //if bucket size is smaller than the current min then set that as the new min
    {
      min6 = hT6.bucket_size(i);
    }
  }
  //assigns the balance to the balance to the hash tables
  std::pair<unsigned int, unsigned int> Balance1(1, max1 - min1);
  std::pair<unsigned int, unsigned int> Balance2(2, max2 - min2);
  std::pair<unsigned int, unsigned int> Balance3(3, max3 - min3);
  std::pair<unsigned int, unsigned int> Balance4(4, max4 - min4);
  std::pair<unsigned int, unsigned int> Balance5(5, max5 - min5);
  std::pair<unsigned int, unsigned int> Balance6(6, max6 - min6);

  //compares the balances of each hash tables
  current_lowest = Balance1;
  if (Balance2.second < current_lowest.second) current_lowest = Balance2;
  if (Balance3.second < current_lowest.second) current_lowest = Balance3;
  if (Balance4.second < current_lowest.second) current_lowest = Balance4;
  if (Balance5.second < current_lowest.second) current_lowest = Balance5;
  if (Balance6.second < current_lowest.second) current_lowest = Balance6;

  // returns the lowest balance hash table
  return current_lowest.first;
  // Hints:
}

// ALREADY COMPLETED
size_t ItemPallet::size() {
    if ((hT1.size() != hT2.size()) || (hT1.size() != hT3.size()) || (hT1.size() != hT4.size()) || (hT1.size() != hT5.size())|| (hT1.size() != hT6.size()) )
  	throw std::length_error("Hash table sizes are not the same");
    
	return hT1.size();
}
