# Project-3
## Warehouse Storage Numbering System with SKUs
In this project, we are to explore chaining in hash tables to help solve a warehouse management system. We given multiple skeletons to fill. These skeletons will return the SKUs accordingly, add items into the custom hash table, remove specific SKUs, and return the hash table with the lowest balance. First, we create pseudo code to solve the problems. Next, implement the pseudo code into actual code and start testing. Through trial and error, compliation and testing, and understanding lectures, we are able to successfully pass the tests and get results!

Clay Golan clayg@csu.fullerton.edu

John Tarroza tarrozajohn@csu.fullerton.edu
